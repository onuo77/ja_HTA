package com.sample.hr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sample.hr.dto.DepartmentDto;
import com.sample.hr.vo.Department;
import com.sample.utils.ConnectionUtil;

/**
 * DEPARTMENTS 테이블에 대한 CRUD 기능을 제공하는 클래스다.
 * @author user
 *
 */
public class DepartmentDao {

	//insert, update,delete 무조건 void!!! / executeUpdate()
	public void insertDepartment(Department department) throws SQLException{
		String sql = "insert into departments "
					+ "(department_id, department_name, manager_id, location_id) "
					+ "values "
					+"(departments_seq.nextval, ?, null, ?) ";
		
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, department.getName());
		pstmt.setInt(2, department.getLocationId());
		pstmt.executeUpdate(); //INSERT, UPDATE, DELETE 구문을 실행한다.
		
		pstmt.close();
		pstmt.close();
	}
	
	//select 일때만 반환타입이 있음!!!!! / executeQuery()
	/**
	 * 모든 부서정보를 반환한다.
	 * @return 부서정보 목록
	 * @throws SQLException
	 */
	public List<Department> getAllDepartments() throws SQLException{
		List<Department> departments = new ArrayList<Department>();
		
		String sql = "select department_id, department_name, manager_id, location_id "
					+ "from departments "
					+ "order by department_id asc ";
		
		Connection con = ConnectionUtil.getConnection();	//DBMS와 연결을 담당하는 Connection 객체 획득
		PreparedStatement pstmt = con.prepareStatement(sql);//지정한 SQL을 DBMS로 전송하는 PreparedStatement 객체 획득
		ResultSet rs = pstmt.executeQuery();				//SQL을 DBMS로 전송하고 실행결과가 포함된 ResultSet 객체 획득
		
		while(rs.next()) {
			Department department = new Department();
			department.setId(rs.getInt("department_id"));
			department.setName(rs.getString("department_name"));
			department.setManagerId(rs.getInt("manager_id"));
			department.setLocationId(rs.getInt("location_id"));
			
			departments.add(department);
		}
		
		rs.close();
		pstmt.close();
		con.close();
		
		return departments;
	}
	
	/**
	 * 부서아이디를 전달받아서 부서기본 정보를 반환한다.
	 * @param deptId 조회할 부서아이디
	 * @return 부서정보가 포함된 DepartmentDto
	 * @throws SQLException
	 */
	public DepartmentDto getDepartmentDto(int deptId) throws SQLException{
		String sql = "select d.department_id, d.department_name, d.manager_id, "
			        +"m.first_name as manager_name, "
			        +"l.location_id, l.city, "
			        +"(select count(*) from employees E where E.department_id = ?) emp_cnt "
					+"from departments d, employees m, locations l "
					+"where d.department_id = ? "
					+"and d.manager_id = m.employee_id(+) "
					+"and d.location_id = l.location_id ";
		
		DepartmentDto dto = null;
		
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, deptId);
		pstmt.setInt(2, deptId);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			dto = new DepartmentDto();
			dto.setId(rs.getInt("department_id"));
			dto.setName(rs.getString("department_name"));
			dto.setManagerId(rs.getInt("manager_id"));
			dto.setManagerName(rs.getString("manager_name"));
			dto.setLocationId(rs.getInt("location_id"));
			dto.setCity(rs.getString("city"));
			dto.setEmpCount(rs.getInt("emp_cnt"));
		}
		
		rs.close();
		pstmt.close();
		con.close();
		
		return dto;
	}
}
